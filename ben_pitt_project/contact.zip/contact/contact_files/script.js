/* Author: Ben Pitt

*/
$(document).ready(function(){
  
  $('#welcome > ul').cycle({ 
      fx:     'fade',
      timeout: 6000
      /*next:   '#next_gallery', 
      prev:   '#prev_gallery' */
  });
});

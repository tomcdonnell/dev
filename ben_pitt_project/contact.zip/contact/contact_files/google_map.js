/*
 * vim: ts=4 sw=4 et wrap co=100 go-=b
 */

jQuery(document).ready(function (ev) {
    $('#contact_locations_list > li').click(onClickLocationLi  );
    $('#footer_locations > li'      ).click(onClickFooterAnchor);

    var url           = window.location.href;
    var lastHashIndex = url.lastIndexOf('#');

    if (lastHashIndex == -1) {
        var locationNo = 0;
    }
    else {
        var cityName   = url.substr(lastHashIndex + 1);
        var locationNo = getLocationIndexFromCityName(cityName);
    }

    var locationLis = $('#contact_locations_list').children();
    $(locationLis[locationNo]).addClass('current');

    updateSelectedLocation(locationNo);
});

/*
 *
 */
function getLocationIndexFromCityName(cityName) {
    cityName = cityName.replace('_', ' ');
    var locationLis = $('#contact_locations_list').children();

    for (var i = 0, len = locationLis.length; i < len; ++i) {
        var text = $(locationLis[i]).text();

        if (text == cityName) {
            return i;
        }
    }

    alert('No li containing text "' + cityName + '" found in ul#contact_locations_list.');
}

/*
 *
 */
function onClickLocationLi(ev) {
    var target = ev.target;
    var li     = (target.nodeName.toLowerCase() == 'a')? $(target).parent()[0]: target;

    $('#contact_locations_list > li').removeClass('current');
    $(li).parent().addClass('current');

    updateSelectedLocation($(li).index());
}

/*
 *
 */
function onClickFooterAnchor(ev) {
    var target      = ev.target;
    var li          = (target.nodeName.toLowerCase() == 'a')? $(target).parent()[0]: target;
    var locationNo  = $(li).index();
    var locationLis = $('#contact_locations_list').children();

    $('#contact_locations_list > li').removeClass('current');
    $(locationLis[locationNo]       ).addClass('current');

    updateSelectedLocation(locationNo);
}

/*
 *
 */
function updateSelectedLocation(locationNo) {
    var locationDivs = $('#locations_text').children();
    var mapDiv       = $('#map_div'       )[0];

    $(mapDiv).html(getInlineFrameHtmlForLocationNo(locationNo));

    for (var i = 0, len = locationDivs.length; i < len; ++i) {
        var locationDiv = locationDivs[i];

        if (i == locationNo) {
            $(locationDiv).show();
        }
        else {
            $(locationDiv).hide();
        }
    }
}

/*
 *
 */
function getInlineFrameHtmlForLocationNo(locationNo)
{
    var locationDivs = $('#locations_text').children();
    var locationDiv  = locationDivs[locationNo];
    var address      = $(locationDiv).find('div.contact_address');
    var streetNo     = $(address).find('span.street_no'   ).text();
    var streetName   = $(address).find('span.street_name' ).text();
    var suburbName   = $(address).find('span.suburb_name' ).text();
    var stateAbbrev  = $(address).find('span.state_abbrev').text();
    var postcode     = $(address).find('span.postcode'    ).text();

    // Example coded address:
    // '390+Flinders+Street+Melbourne+VIC+3000&amp;ie=UTF8&amp;' .
    // 'hnear=390+Flinders+St+Melbourne+Victoria+3000'
    var codedAddress = streetNo + '+' + streetName + '+' + stateAbbrev + '+' + postcode;
    codedAddress     = codedAddress.replace(' ', '+');

    return (
        '<iframe width="480" height="340" frameborder="0" scrolling="no" marginheight="0" ' +
        'marginwidth="0" src="http://www.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;' +
        'geocode=&amp;q=' + codedAddress + '&amp;ie=UTF8&amp;hnear=' + codedAddress         +
        '+Australia&amp;output=embed"></iframe>'
    );
}
